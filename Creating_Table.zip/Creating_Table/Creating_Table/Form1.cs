﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Creating_Table
{
    public partial class Form1 : Form
    {
        TextBox txtfiledname = new TextBox();
        ComboBox cmbdatatype = new ComboBox();
        TextBox txtsize = new TextBox();
        int fieldcount = 0;
        int check = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {
                int y = 135;
                fieldcount = Convert.ToInt32(textBox2.Text);
                for (int i = 1; i <= fieldcount; i++)
                {
                    y += 40;
                    txtfiledname = new TextBox();
                    txtfiledname.Name = "txtfiledname" + i.ToString();
                    this.Controls.Add(txtfiledname);
                    txtfiledname.Height = 22;
                    txtfiledname.Width = 100;
                    txtfiledname.Location = new System.Drawing.Point(14, y);

                    cmbdatatype = new ComboBox();
                    cmbdatatype.Name = "cmbdatatype" + i.ToString();
                    cmbdatatype.TextChanged += new EventHandler(ShowMessage);
                    this.Controls.Add(cmbdatatype);
                    cmbdatatype.Items.Add("varchar");
                    cmbdatatype.Items.Add("int");
                    cmbdatatype.Height = 22;
                    cmbdatatype.Width = 100;
                    cmbdatatype.Location = new System.Drawing.Point(125, y);

                    txtsize = new TextBox();
                    txtsize.Name = "txtsize" + i.ToString();
                    this.Controls.Add(txtsize);
                    txtsize.Height = 22;
                    txtsize.Width = 100;
                    txtsize.Location = new System.Drawing.Point(235, y);
                }
            }
            else
            {
                MessageBox.Show("Enter value of field or name");
            }
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {

            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string fields = "";
            if (txtfiledname.Text != "" && cmbdatatype.Text != "")
            {

                for (int i = 1; i <= fieldcount; i++)
                {
                    if (this.Controls["cmbdatatype" + i.ToString()].Text == "varchar")
                    {
                        if (this.Controls["txtsize" + i.ToString()].Text != "")
                        {
                            check = 1;
                            if (i == fieldcount)
                            {
                                fields += this.Controls["txtfiledname" + i.ToString()].Text + " " + this.Controls["cmbdatatype" + i.ToString()].Text + " (" + this.Controls["txtsize" + i.ToString()].Text + ")";
                            }
                            else
                            {
                                fields += this.Controls["txtfiledname" + i.ToString()].Text + " " + this.Controls["cmbdatatype" + i.ToString()].Text + " (" + this.Controls["txtsize" + i.ToString()].Text + "),";
                            }
                        }
                        else
                        {
                            check = 0;
                            MessageBox.Show("Please Enter Size");
                        }
                    }
                    else
                    {
                        if (i == fieldcount)
                        {
                            fields += this.Controls["txtfiledname" + i.ToString()].Text + " " + this.Controls["cmbdatatype" + i.ToString()].Text;
                        }
                        else
                        {
                            fields += this.Controls["txtfiledname" + i.ToString()].Text + " " + this.Controls["cmbdatatype" + i.ToString()].Text + ",";
                        }
                    }
                }
                if (check == 1)
                {
                    string sql = "create table " + textBox1.Text + " (" + fields + ")";
                    SqlDataAdapter adapter = new SqlDataAdapter(sql, Class1.cn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);
                    MessageBox.Show("Your Table is Created");
                    this.Close();
                }
            }
            else
            {
                MessageBox.Show("Enter Value");
            }

        }
        private void ShowMessage(object sender, EventArgs e)
        {
            for (int i = 1; i <= fieldcount; i++)
            {
                if (this.Controls["cmbdatatype" + i.ToString()].Text == "int")
                {
                    //this.Controls.Remove(this.Controls["txtsize" + i.ToString()]);
                    this.Controls["txtsize" + i.ToString()].Enabled = false;
                }
                else
                {
                    //this.Controls.Add(this.Controls["txtsize" + i.ToString()]);
                    this.Controls["txtsize" + i.ToString()].Enabled = true;
                }
            }
        }
    }
}

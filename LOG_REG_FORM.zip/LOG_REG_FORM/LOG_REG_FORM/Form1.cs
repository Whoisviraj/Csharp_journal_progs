﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace LOG_REG_FORM
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void but1_Click(object sender, EventArgs e)
        {
            if (txtnm.Text != "" && txtemail.Text != "" && txtpass.Text != "" && date.Text != "" && combo.Text != "")
            {
                String query = "insert into reg values('" + txtnm.Text + "','" + txtemail.Text + "','" + txtpass.Text + "','" + date.Text + "','" + combo.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(query, Class1.cn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                clear();
            }
            else
            {
                MessageBox.Show("please enter details");
            }
           


        }
        private void clear()
        {
            txtnm.Text = "";
            txtemail.Text = "";
            txtpass.Text = "";
            date.Text = "";
            combo.Text = "";
            txtnm.Focus();
            
        }

        private void btn2_Click(object sender, EventArgs e)
        {
             Form2 frm2 = new Form2();
                        frm2.Show();
                        this.Hide();
        }
       


}
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace LOG_REG_FORM
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            Form1 frm1 = new Form1();
            frm1.Show();
            this.Hide();
        }

        private void btn1_Click(object sender, EventArgs e)
        {

            if (txt1.Text != "" && txt2.Text != "")
          {
                
                String sql = "Select * From reg where fnm='"+txt1.Text+"' and password='"+txt2.Text+"'";
                SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
                DataTable dt = new DataTable();
                
                 da.Fill(dt);
                 if (dt.Rows.Count > 0)
              {
                  hellow frm3 = new hellow();
                  frm3.Show();
                  this.Hide();
              }
              else
              {
                  MessageBox.Show("Please enter the correct value");
              }
            }
            else
            {
                MessageBox.Show("Please enter the value");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace LOG_REG_FORM
{
    public partial class hellow : Form
    {
        int totrecords;
        int curtrecord = 0;
        DataTable dtg = new DataTable();
        public hellow()
        {
            InitializeComponent();
        }

        private void hellow_Load(object sender, EventArgs e)
        {
            string sql = "select * from reg";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable(); 
            da.Fill(dtg);
            totrecords = dtg.Rows.Count;
            navigate();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            curtrecord = 0;
            navigate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (curtrecord < totrecords - 1)
            {
                curtrecord++;
                navigate();
            }
            else
            {
                MessageBox.Show("already in last value");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (curtrecord > 0)
            {
                curtrecord--;
                navigate();
            }
            else
            {
                MessageBox.Show("already on first record");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            curtrecord = totrecords - 1;
            navigate();
        }
        private void navigate()
        {
            txtnm.Text = dtg.Rows[curtrecord]["fnm"].ToString();
            txtemail.Text = dtg.Rows[curtrecord]["email"].ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sql = "select * from reg";
            SqlDataAdapter da = new SqlDataAdapter(sql, Class1.cn);
            DataTable dt = new DataTable();
            da.Fill(dtg);
            totrecords = dtg.Rows.Count;
            navigate();
        }
    }
}

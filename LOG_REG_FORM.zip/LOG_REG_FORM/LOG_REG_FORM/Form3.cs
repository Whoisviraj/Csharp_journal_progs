﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LOG_REG_FORM
{
    public partial class hellow : Form
    {
        public hellow()
        {
            InitializeComponent();
        }
    }
}

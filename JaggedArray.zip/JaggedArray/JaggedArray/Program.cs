﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace JaggedArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[][] arr = new int[2][];

            arr[0] = new int[4] { 10, 21, 30, 28 };
            arr[1] = new int[5] { 04, 16, 20, 10, 27,  };

            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    Console.Writeline(arr[i][j] + "__");
                    
                }
            }
            Console.Read();
        }
    }
}

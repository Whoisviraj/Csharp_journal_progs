﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1D_Array
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] games = { "BGMI", "FREEFIRE", "ASPHALT9", "Clashofclains" };
            foreach (string val in games)
            {
                Console.WriteLine(val);
            }
              Console.Read();
        }
    }
}

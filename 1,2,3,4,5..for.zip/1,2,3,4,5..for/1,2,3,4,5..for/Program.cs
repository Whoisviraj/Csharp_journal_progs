﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_2_3_4_5._.@for
{
    class Program
    {
        public static void Main(string []args)
        {
            int i;
           
            for (i = 1; i <= 5; i++)
            {
                Console.Write("{0} ", i);
            }
            Console.Write("\n\n");
            Console.ReadLine();
        }
    }
}
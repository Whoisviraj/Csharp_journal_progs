﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class Marksheet
{

    static void Main(string[] args)
    {
        int r, m1, m2, m3, total;
        float percentage;
        string n;

        Console.WriteLine("Enter Student Roll Number :");
        r = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter Student Name :");
        n = Console.ReadLine();

        Console.WriteLine("Enter Marks1 : ");
        m1 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter Marks2 : ");
        m2 = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("Enter Marks3 :");
        m3 = Convert.ToInt32(Console.ReadLine());

        total = m1 + m2 + m3;

        percentage = total / 3.0f;

        Console.WriteLine("Result of student is s: "+ n);
        Console.WriteLine("Total Marks : " + total);
        Console.WriteLine("Percentage : " + percentage);
        

        if (percentage <= 35)
        {
            Console.WriteLine("Grade is F");
        }
        else if (percentage >= 34 && percentage <= 39)
        {
            Console.WriteLine("Grade is D");
        }
        else if (percentage >= 40 && percentage <= 59)
        {
            Console.WriteLine("Grade is C");
        }
        else if (percentage >= 60 && percentage <= 69)
        {
            Console.WriteLine("Grade is B");
        }
        else if (percentage >= 70 && percentage <= 79)
        {
            Console.WriteLine("Grade is B+");
        }
        else if (percentage >= 80 && percentage <= 90)
        {
            Console.WriteLine("Grade is A");
        }
        else if (percentage >= 91)
        {
            Console.WriteLine("Grade is A+");
        }
        Console.ReadLine();
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12358FOR
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1 = 0, n2 = 1, n3;
            Console.Write("Enter the number of Digits : ");
            int number = int.Parse(Console.ReadLine());

            for (int i = 2; i < number; ++i)
            {
                n3 = n1 + n2;
                Console.Write(n3 + " ");
                n1 = n2;
                n2 = n3;

            }
            Console.Read();
        }
    }
}

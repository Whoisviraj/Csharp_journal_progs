﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace operators
{
    class Program
    {
        static void Main(string[] args)
        {
            int c;

            Console.WriteLine("enter a:");
            int a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter b:");
            int b = Convert.ToInt32(Console.ReadLine());

            //arithmetic operator
            c = a + b;
            Console.WriteLine("sum of a and b is:"+c);
            c = a - b;
            Console.WriteLine("sub of a and b is:" + c);
            c = a * b;
            Console.WriteLine("mul of a and b is:" + c);
            c = a / b;
            Console.WriteLine("div of a and b is:" + c);
            c = a % b;
            Console.WriteLine("modu of a and b is:" + c);

            //relational operator
            if (a == b)
            {
                Console.WriteLine("a is equal to b");
            }
            if (a > b)
            {
                Console.WriteLine("a is greatre than b");
            }
            if (a < b)
            {
                Console.WriteLine("a is less than b");
            }
            if (a >= b)
            {
                Console.WriteLine("a is greatre or equal to b");
            }
            if (a <= b)
            {
                Console.WriteLine("a is less or equal to b");
            }
            if (a != b)
            {
                Console.WriteLine("a is not equal b");
            }

            //logical operator
            bool m = true, n = false, res;
            res = m && n;
            Console.WriteLine("AND Operator: " + res);
            res = m || n;
            Console.WriteLine("OR Operator: " + res);
            res = !m;
            Console.WriteLine("NOT Operator: " + res);

            //bitwise operator

            c = a | b;
            Console.WriteLine("Bitwise OR: " + c);
            c = a ^ b;
            Console.WriteLine("Bitwise XOR: " + c);
            c = ~a;
            Console.WriteLine("Bitwise Complement: " + c);
            c = a << 2;
            Console.WriteLine("Bitwise Left Shift: " + c);
            c = a >> 2;
            Console.WriteLine("Bitwise Right Shift: " + c);
            Console.Read();
        }
    }
}

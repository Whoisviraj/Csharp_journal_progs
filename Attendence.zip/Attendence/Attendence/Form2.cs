﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Attendence
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sql = "select * from studatt where course='" + comboBox1.Text + "' and div='" + comboBox2.Text + "' ORDER BY roll";
            SqlDataAdapter adapter = new SqlDataAdapter(sql, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Vir\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                comboBox3.DataSource = dt;
                comboBox3.DisplayMember = "roll";
            }
            else
            {
                MessageBox.Show("No Records Found!");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text != ""&& comboBox2.Text!="" && comboBox3.Text!="" && comboBox4.Text!="")
            {
                DateTime dt = DateTime.Now;
                string dt1 = dt.ToShortDateString();
                string attn = "";
                if (comboBox4.Text == "present")
                {
                    attn = "P";
                }
                else if (comboBox4.Text == "absent")
                {
                    attn = "A";
                }
                else if (comboBox4.Text == "leave")
                {
                    attn = "L";
                }
                string sql1 = "select * from attendence where course='" + comboBox1.Text + "' and div='" + comboBox2.Text + "' and roll='" + comboBox3.Text + "' and date='" + dt1 + "'";
                SqlDataAdapter da1 = new SqlDataAdapter(sql1, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Vir\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                DataTable dt3 = new DataTable();
                da1.Fill(dt3);

                if (dt3.Rows.Count == 0)
                {
                    string sql = "insert into attendence values('" + comboBox1.Text + "','" + comboBox2.Text + "','" + comboBox3.Text + "','" + attn + "','" + dt1 + "')";
                    SqlDataAdapter da = new SqlDataAdapter(sql, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\Vir\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                    DataTable dt2 = new DataTable();
                    int a = da.Fill(dt2);
                    if (a == 0)
                    {
                        MessageBox.Show("Attendance Taken");
                        clear();
                    }
                    else
                    {
                        MessageBox.Show("There Was Some Error");
                        clear();
                    }
                }
                else
                {
                    MessageBox.Show("Attendence Already taken", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    clear();
                }
            }
            else
            {
                MessageBox.Show("Please select items", "You can do that mistake", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
            

        private void clear()
        {
            comboBox1.Text = "";
            comboBox2.Text = "";
            comboBox3.Text = "";
            comboBox4.Text = "";
            comboBox1.Focus();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Close();
        }
    }
}

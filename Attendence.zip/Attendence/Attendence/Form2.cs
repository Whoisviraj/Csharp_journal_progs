﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Attendence
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
             if (chka.Checked == true && chkp.Checked == true)
            {
                MessageBox.Show("Please check only one check box idiot!!!", "Oopsi!!!", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            }
            else
            {
                if (comboBox1.Text != "" && chka.Checked != false || chkp.Checked != false)
                {
                    
                    
                    
                    string sel = "select * from attendence where roll = '" + comboBox1.Text + "' and doatt = '" + dateTimePicker1.Value.Date.ToString() + "'";
                    SqlDataAdapter dsel1 = new SqlDataAdapter(sel, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                    DataTable dtsel1 = new DataTable();
                    dsel1.Fill(dtsel1);
                    if (dtsel1.Rows.Count == 0)
                    {
                        if (chkp.Checked == true)
                        {

                            string ins = "insert into attendence values('" + comboBox1.Text + "','" + chkp.Text + "','" + dateTimePicker1.Value.Date.ToString() + "')";
                            SqlDataAdapter dins = new SqlDataAdapter(ins, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                            DataTable dtins = new DataTable();
                            dins.Fill(dtins);
                            MessageBox.Show("Attendance submited");
                        }
                        else
                        {
                            string date = chka.Text + dateTimePicker1.Value.Date.ToString();
                            string ins = "insert into attendence values('" + comboBox1.Text + "','" + chka.Text + "','" + dateTimePicker1.Value.Date.ToString() + "')";
                            SqlDataAdapter dins = new SqlDataAdapter(ins, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                            DataTable dtins = new DataTable();
                            dins.Fill(dtins);
                            MessageBox.Show("Attendance submited");
                        }
                    }
                    else
                    {
                        MessageBox.Show("You already have submited todays attendance!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    }
                }
                else
                {
                    MessageBox.Show("Kindly select appropriate check box!!");
                }
            }
        }
        
        private void Form2_Load(object sender, EventArgs e)
        {
            string sel = "select * from studatt";
            SqlDataAdapter dsel = new SqlDataAdapter(sel, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            DataTable dtsel = new DataTable();
            dsel.Fill(dtsel);
            comboBox1.DataSource = dtsel;
            comboBox1.DisplayMember = "roll";
            dateTimePicker1.Value = System.DateTime.Now;
            string date = dateTimePicker1.Value.Date.ToShortDateString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Hide();
        }

        private void groupBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
            string sel3 = "select * from stddata where rlno = '" + comboBox1.Text + "'";
            SqlDataAdapter dsel3 = new SqlDataAdapter(sel3, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
            DataTable dtsel3 = new DataTable();
            dsel3.Fill(dtsel3);
            textBox1.Text = dtsel3.Rows[0]["name"].ToString();
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {

                string sel3 = "select * from studatt where roll = '" + comboBox1.Text + "'";
                SqlDataAdapter dsel3 = new SqlDataAdapter(sel3,@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                DataTable dtsel3 = new DataTable();
                dsel3.Fill(dtsel3);
                textBox1.Text = dtsel3.Rows[0]["name"].ToString();

            }
            catch (IndexOutOfRangeException a)
            {
                MessageBox.Show("Welcome user!!!!", "Welcome", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

  
       
    }
}

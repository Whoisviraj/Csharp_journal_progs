﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Attendence
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnreg_Click(object sender, EventArgs e)
        {

            if (txtnm.Text != "" && comboBox1.Text != "" && txtrlno.Text != "" && txtcn.Text != "" && comboBox2.Text != "")
            {
                string sel = "select * from studatt where roll = '" + txtrlno.Text + "'";
                SqlDataAdapter ds = new SqlDataAdapter(sel, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                DataTable dts = new DataTable();
                ds.Fill(dts);

                if (dts.Rows.Count > 0)
                {
                    MessageBox.Show("Please check Roll number!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    string ins = "insert into studatt values('" + txtrlno.Text + "','" + txtnm.Text + "','" + comboBox1.Text + "','" + comboBox2.Text + "','" + txtcn.Text + "')";
                    SqlDataAdapter din = new SqlDataAdapter(ins, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\Attendence\Attendence\bin\Debug\Student.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
                    DataTable dtin = new DataTable();
                    din.Fill(dtin);
                    MessageBox.Show("Registered!!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("Please enter all values!!", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            Form2 form2 = new Form2();
            form2.Show();
            this.Hide();
        }

        private void btnclr_Click(object sender, EventArgs e)
        {

            txtnm.Text = "";
            comboBox1.Text = "";
            txtrlno.Text = "";
            txtcn.Text = "";
            comboBox2.Text = "";
            txtrlno.Focus();
        }

    }
}

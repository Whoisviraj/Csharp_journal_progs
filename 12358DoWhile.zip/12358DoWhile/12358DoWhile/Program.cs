﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12358DoWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1 = 0, n2 = 1, n3;
            Console.Write("Enter the number of elements: ");
            int number = int.Parse(Console.ReadLine());

            int i = 2;

            do
            {

                n3 = n1 + n2;
                Console.Write(n3 + " ");
                n1 = n2;
                n2 = n3;

                ++i;

            }
            while (i < number);

            Console.Read();
        }
    }
}

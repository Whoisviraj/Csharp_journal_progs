﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ElectriciyBill
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            string sql = "select * from customer";
            SqlDataAdapter da = new SqlDataAdapter(sql, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\ElectriciyBill\ElectriciyBill\bin\Debug\Db1.mdf;Integrated Security=True;User Instance=True");
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox1.DataSource = dt;
            comboBox1.DisplayMember = "meter_no";
            button1.Enabled = false;
        }
      
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            string query = "select * from bill where meter_no='" + comboBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\ElectriciyBill\ElectriciyBill\bin\Debug\Db1.mdf;Integrated Security=True;User Instance=True");
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    textBox1.Text = dt.Rows[i][2].ToString();
                }
            }
            else
            {
                textBox1.Text = "0";
            }
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
              if ( textBox2.Text != "")
           {
               string sql1 = "insert into bill values('" + comboBox1.Text + "','" + textBox1.Text + "','" + textBox2.Text + "','" + comboBox2.Text + "','" + textBox3.Text + "')";
               SqlDataAdapter da1 = new SqlDataAdapter(sql1, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\ElectriciyBill\ElectriciyBill\bin\Debug\Db1.mdf;Integrated Security=True;User Instance=True");
               DataTable dt1 = new DataTable();
               da1.Fill(dt1);
               MessageBox.Show("Record Inserted");
           }
           else
           {
               MessageBox.Show("Please enter the values...");
           }
              clear();
        }

        private void comboBox2_TextChanged(object sender, EventArgs e)
        {
            string query = "select * from bill where meter_no='" + comboBox1.Text + "' and month='"+comboBox2.Text+"'";
            SqlDataAdapter da3 = new SqlDataAdapter(query, @"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\ElectriciyBill\ElectriciyBill\bin\Debug\Db1.mdf;Integrated Security=True;User Instance=True");
            DataTable dt3 = new DataTable();
            da3.Fill(dt3);
            if (dt3.Rows.Count > 0)
            {                               
                    MessageBox.Show("already exist");
                    button1.Enabled = false;
            } 
            else
            {

                int prev_unit = Convert.ToInt32(textBox1.Text);
                if (textBox2.Text != "")
                {
                    int curr_unit = Convert.ToInt32(textBox2.Text);

                    int unit = curr_unit - prev_unit;
                    int amount = unit * 7;
                    textBox3.Text = amount.ToString();
                }
                else {
                    MessageBox.Show("Please enter current record... ");
                }
                button1.Enabled = true;
                
            }
        }

        private void clear()
        {
          textBox2.Text = "";
            textBox3.Text = "";
            comboBox2.Text = "";
            comboBox1.Text = "";
            textBox1.Text = "";

 
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace ElectriciyBill
{
    public partial class Form2 : Form
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=E:\viraj\ElectriciyBill\ElectriciyBill\bin\Debug\Db1.mdf;Integrated Security=True;User Instance=True");
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "Select * from customer where meter_no='" + textBox2.Text + "'";
            SqlDataAdapter da=new SqlDataAdapter(sql,cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
           if (dt.Rows.Count>0)
           {
               MessageBox.Show("already exist...");
           }
           else if (textBox1.Text != "" && textBox2.Text != "")
           {
               string sql1 = "insert into customer values('" + textBox1.Text + "','" + textBox2.Text + "')";
               SqlDataAdapter da1 = new SqlDataAdapter(sql1, cn);
               DataTable dt1 = new DataTable();
               da1.Fill(dt1);
               MessageBox.Show("Record Inserted");
           }
           else
           {
               MessageBox.Show("Please enter the values...");
           }
           clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            clear();
        }
          private void clear()
         {
                textBox1.Text = "";
                textBox2.Text = "";
         }
         protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
         {
                if (keyData == Keys.Escape)
              {
                 this.Close();
              }
                 return base.ProcessCmdKey(ref msg, keyData);
        }

         private void Form2_FormClosing(object sender, FormClosingEventArgs e)
         {
             Application.Exit();
         }
      
    }
}

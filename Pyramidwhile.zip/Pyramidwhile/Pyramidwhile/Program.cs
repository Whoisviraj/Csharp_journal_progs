﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Pyramidwhile
{
    class Program
    {

        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 5)
            {
                int j = 1;
                while (j <= i)
                {
                    Console.Write(j + " ");
                    j++;
                }
                i++;
                Console.WriteLine();
            }
            Console.Read();
        }
    }
}

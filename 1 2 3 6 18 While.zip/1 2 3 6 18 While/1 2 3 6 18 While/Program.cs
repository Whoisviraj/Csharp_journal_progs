﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_2_3_6_18_While
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1 = 1, n2 = 2, n3 = 3, n4;
            Console.Write("Enter the number of Digits: ");
            int number = int.Parse(Console.ReadLine());
            Console.Write(n1 + " " + n2 + " " + n3 + " ");

            int i = 2;

            while (i < number)
            {
                n4 = n3 * n2;
                Console.Write(n4 + " ");
                n1 = n2;
                n2 = n3;
                n3 = n4;

                ++i;
            }
            Console.Read();
        }
    }
}

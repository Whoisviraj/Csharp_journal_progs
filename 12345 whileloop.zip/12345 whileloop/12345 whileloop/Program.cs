﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _12345_whileloop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;
            while (i <= 5)
            {
                Console.Write(i);
                i++;
            }
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pyramid12345
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            for (i = 1; i <= 5; i++)
            {
                for (j = i; j<=i; j++)


                    Console.Write(j);
                    Console.ReadLine();
            }
        }
    }
}

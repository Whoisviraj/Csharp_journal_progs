﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Boxing_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {     
        int num = 2020;
        object obj = num;
        int i = (int)obj;
        num = 100;
        System.Console.WriteLine
        ("Value - type value of num is : {0}", num);
        System.Console.WriteLine
        ("Object - type value of boxing : {0}", obj);
        System.Console.WriteLine
   ("Object - type value of unboxing is : {0}", i);
        Console.ReadLine();
    }
}
        }
    


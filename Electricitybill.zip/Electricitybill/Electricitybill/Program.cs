﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Electricitybill
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a unit of electricity bil : ");
            int unit = Convert.ToInt32(Console.ReadLine());
            int tot = 0;
            Console.WriteLine("1.Rural(Unit:1 to 400) \t 2.Urban(Unit:401 upto)");
            Console.WriteLine("Choose above any one area : ");
            int area = Convert.ToInt32(Console.ReadLine());
            switch (area)
            {
                case 1:
                    if (unit <= 100)
                    {
                        tot = unit * 10;
                        Console.WriteLine("as per 1. Total Rs. : " + tot);
                    }
                    else if (unit > 100 && unit <= 200)
                    {
                        unit = unit * 15;
                        Console.WriteLine("as per 2 .Total Rs. : " + unit);
                    }
                    else if (unit > 200 && unit <= 400)
                    {
                        unit = unit * 20;
                        Console.WriteLine("as per 3. Total Rs. : " + unit);
                    }
                    else
                    {
                        Console.WriteLine("You are come in Urban area.");
                    }
                    break;

                case 2:
                    if (unit > 400 && unit <= 600)
                    {
                        unit = unit * 25;
                        Console.WriteLine(" as per 4. Total Rs. : " + unit);
                    }
                    else if (unit > 600 && unit <= 800)
                    {
                        unit = unit * 30;
                        Console.WriteLine("as per 5. Total Rs. : " + unit);
                    }
                    else if (unit > 800)
                    {
                        unit = unit * 40;
                        Console.WriteLine(" as per 6. Total Rs. : " + unit);
                    }
                    else
                    {
                        Console.WriteLine("You are come in Rural area.");
                    }
                    break;

            }

            Console.ReadKey(true);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Electricitybill
{
    class Program
    {
        static void Main(string[] args)
        {
            int units = Convert.ToInt16(Console.ReadLine());
            int pc1, pc2,  a ;
            Console.WriteLine("The Electricity  Bill  Calculation");
            if (units <= 80)
            {

                pc1 = (units * 6);
                Console.WriteLine("The power Consumption is={0}", pc1);

            }
            else if (units > 80 && units <= 180)
            {
                a = units - 80;
                pc2 = (a * 12) + 480;
                Console.WriteLine("The power Consumption is={0}", pc2);

            } Console.ReadLine();
        }
    }
}
